/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/xilinx/practica13/convertidor.vhd";
extern char *IEEE_P_3620187407;

int ieee_p_3620187407_sub_5109402382352621412_3965413181(char *, char *, char *);
unsigned char ieee_p_3620187407_sub_970019341842429312_3965413181(char *, char *, char *, int );


static void work_a_2395085759_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    int t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4744U);
    t3 = ieee_p_3620187407_sub_970019341842429312_3965413181(IEEE_P_3620187407, t2, t1, 10);
    if (t3 != 0)
        goto LAB3;

LAB4:
LAB5:    t18 = (t0 + 4890);
    t20 = (t0 + 2864);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t18, 7U);
    xsi_driver_first_trans_fast_port(t20);

LAB2:    t25 = (t0 + 2784);
    *((int *)t25) = 1;

LAB1:    return;
LAB3:    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    t4 = (t0 + 4744U);
    t7 = ieee_p_3620187407_sub_5109402382352621412_3965413181(IEEE_P_3620187407, t6, t4);
    t8 = (t7 - 0);
    t9 = (t8 * 1);
    xsi_vhdl_check_range_of_index(0, 9, 1, t7);
    t10 = (7U * t9);
    t11 = (0 + t10);
    t12 = (t5 + t11);
    t13 = (t0 + 2864);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t12, 7U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB2;

LAB6:    goto LAB2;

}


extern void work_a_2395085759_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2395085759_3212880686_p_0};
	xsi_register_didat("work_a_2395085759_3212880686", "isim/simulacion_isim_beh.exe.sim/work/a_2395085759_3212880686.didat");
	xsi_register_executes(pe);
}
